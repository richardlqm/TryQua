from typing import Dict


class QOPConfig(object):
    def __init__(self, raw_config: Dict):
        self._raw_config = raw_config
        self._pulses = self._raw_config["pulses"]
        self._elements = self._raw_config["elements"]
        self._qe_names = list(self._elements)
        self._waveforms = self._raw_config["waveforms"]

    def get_qe_names(self):
        return self._qe_names

    def get_pulse_duration(self, qe_name, operation_name) -> int:
        pulse = self.get_pulse_config(operation_name, qe_name)
        return pulse['length']

    def get_pulse_config(self, operation_name, qe_name):
        qe_config = self.get_qe_configuration(qe_name)
        operations = qe_config["operations"]
        try:
            pulse_name = operations[operation_name]
        except KeyError:
            raise ModuleNotFoundError(f"Operation \"{operation_name}\" not found for QE \"{qe_name}\"")
        try:
            pulse = self._pulses[pulse_name]
        except KeyError:
            raise ModuleNotFoundError(f"Pulse \"{pulse_name}\" was not defined")
        return pulse

    def get_time_of_flight(self, qe_name):
        qe = self.get_qe_configuration(qe_name)
        return qe['time_of_flight']

    def get_qe_configuration(self, qe_name):
        try:
            qe = self._elements[qe_name]
        except KeyError:
            raise ModuleNotFoundError(f'QE \"{qe_name}\" not found in config')
        return qe

    def get_smearing(self, qe_name):
        qe = self.get_qe_configuration(qe_name)
        return qe['smearing']

    def get_operation_waveforms(self, operation_name, qe_name):
        pulse_config = self.get_pulse_config(operation_name, qe_name)
        operation_waveforms = pulse_config['waveforms']
        if 'single' in operation_waveforms:
            wf_name = operation_waveforms['single']
            try:
                wf = self._waveforms[wf_name]
                return wf, None
            except KeyError:
                raise ModuleNotFoundError(f"Waveform \"{wf_name}\" not defined")
        try:
            wf_name_I = operation_waveforms['I']
        except KeyError:
            raise ModuleNotFoundError(f"No I waveform for operation \"{operation_name}\"")
        try:
            wf_name_Q = operation_waveforms['Q']
        except KeyError:
            raise ModuleNotFoundError(f"No Q waveform for operation \"{operation_name}\"")
        try:
            wf_I = self._waveforms[wf_name_I]
        except KeyError:
            raise ModuleNotFoundError(f"Waveform I \"{wf_name_I}\" not defined")
        try:
            wf_Q = self._waveforms[wf_name_Q]
        except KeyError:
            raise ModuleNotFoundError(f"Waveform Q \"{wf_name_Q}\" not defined")
        return wf_I, wf_Q