import pickle
import random
from typing import List

from qm import qua
from qm.qua._dsl import _get_scope_as_blocks_body, _BodyScope
from qm.program.StatementsCollection import StatementsCollection
from qm.qua.lib import call_library_function


def register_qua_instruction(instruction):
    def decorated(**kwargs):
        body = _get_scope_as_blocks_body()
        statement = body._body.statements.add()
        # a working bad solution is better than none
        statement.rus.SetInParent()
        statement.rus.loc = "{} {}".format(instruction.__name__, pickle.dumps(kwargs).hex())
    return decorated


def register_qua_context(context):
    def decorated(**kwargs):
        body = _get_scope_as_blocks_body()
        # a working bad solution is better than none
        qrun_statement = body.qrun_block()
        qrun_statement.loc = "@{} {}".format(context.__name__, pickle.dumps(kwargs).hex())
        return _BodyScope(StatementsCollection(qrun_statement.body))
    return decorated


@register_qua_instruction
def wait_for_value(value, min_time: int = None, max_time: int = None, qes: List[str] = None):
    pass


@register_qua_instruction
def say(msgs: List):
    pass


@register_qua_instruction
def assert_(condition, message=''):
    pass


@register_qua_instruction
def beep():
    pass


def acquire(element: str, stream=None, *outputs):
    qua.measure('', element, stream, *outputs)


@register_qua_context
def parallel_():
    pass


class function_scope(_BodyScope):
    def __init__(self, body, name:str):
        super().__init__(body)
        self._name = name

    def __enter__(self):
        super().__enter__()

        @register_qua_instruction
        def call_function(name, args):
            pass

        def _call_function(args=[]):
            call_function(name=self._name, args=args)

        class _():
            def __call__(self, *args, **kwargs):
                _call_function(args=kwargs)

            def __getattr__(self, item):
                expression = call_library_function('user', 'get',())
                expression._exp.libFunction.loc = item
                return expression

        return _()

    def __exit__(self, exc_type, exc_val, exc_tb):
        return super().__exit__(exc_type, exc_val, exc_tb)


def def_function(**kwargs):
    function_name = f'_{random.randint(0, 10000)}'
    body = _get_scope_as_blocks_body()
    # a working bad solution is better than none
    qrun_statement = body.qrun_block()
    qrun_statement.loc = "@{} {}".format('def_function', pickle.dumps({'name': function_name, 'arguments': kwargs}).hex())
    return function_scope(StatementsCollection(qrun_statement.body), function_name)
