import numpy as np
from scipy.signal.windows import gaussian


#############
# VARIABLES #
#############

# Qubits
qubit_IF = 50e6
cooling_IF = 74e6
repump_IF = 80e6
qubit_LO = 7e9
mixer_qubit_g = 0.0
mixer_qubit_phi = 0.0

saturation_len = 1000
saturation_amp = 0.1
const_len = 100
const_amp = 0.4

gauss_len = 50

sqrt_amp = 0.2
gauss_sigma = gauss_len / 5
gauss_amp = 0.45
gauss_wf = gauss_amp * gaussian(gauss_len, gauss_sigma)
sqrt_wf = np.sqrt(np.linspace(0, sqrt_amp, const_len))
pi_len = 40
pi_sigma = pi_len / 5
pi_amp = 0.35
pi_wf = pi_amp * gaussian(pi_len, pi_sigma)
pi_half_len = 40
pi_half_sigma = pi_half_len / 5
pi_half_amp = pi_amp / 2
pi_half_wf = pi_half_amp * gaussian(pi_half_len, pi_half_sigma)


# Resonator
resonator_IF = 60e6
resonator_LO = 5.5e9
mixer_resonator_g = 0.0
mixer_resonator_phi = 0.0

short_readout_len = 500
short_readout_amp = 0.4
readout_len = 5000
readout_amp = 0.2
long_readout_len = 50000
long_readout_amp = 0.1
timetagging_len = 4500

##########
# CONFIG #
##########
con = 'con1'
config = {
    'version': 1,
    'controllers': {
        con: {
            'type': 'opx1',
            'analog_outputs': {
                i: {'offset': 0.0} for i in range(1, 11)
            },
            'analog_inputs': {
                1: {'offset': 0.0, 'gain_db': 0},  # I from downconversion
                2: {'offset': 0.0, 'gain_db': 0},  # Q from downconversion
            },
            "digital_outputs": {1: {}, 2: {}, 3: {}, 4: {}, 5: {}, 6: {}, 7: {}},
        },
    },
    'elements': {
        'qb1': {
            'mixInputs': {
                'I': (con, 1),
                'Q': (con, 2),
                'lo_frequency': 0.0,
                'mixer': 'mixer_qubit',
            },
            'intermediate_frequency': 50e6,
            'operations': {
                'cw': 'cw',
                'gauss': 'gaussian_pulse',
                'pi': 'pi_pulse',
                'pi_half': 'pi_half_pulse',
            },
        },
        'qb2': {
            'mixInputs': {
                'I': (con, 3),
                'Q': (con, 4),
                'lo_frequency': 0.0,
                'mixer': 'mixer_qubit',
            },
            'intermediate_frequency': 50e6,
            'operations': {
                'cw': 'cw',
                'gauss': 'gaussian_pulse',
                'pi': 'pi_pulse',
                'pi_half': 'pi_half_pulse',
            },
        },
        'qb3': {
            'singleInput': {
                'port': (con, 5),
                'lo_frequency': 0.0,
            },
            'intermediate_frequency': 50e6,
            'operations': {
                'cw': 'cw_single',
                'gauss': 'gaussian_pulse_single',
                'pi': 'pi_pulse_single',
                'pi_half': 'pi_half_pulse_single',
            },
        },
        'qb4': {
            'singleInput': {
                'port': (con, 5),
                'lo_frequency': 0.0,
            },
            'intermediate_frequency': 50e6,
            'operations': {
                'cw': 'cw_single',
                'gauss': 'gaussian_pulse_single',
                'pi': 'pi_pulse_single',
                'pi_half': 'pi_half_pulse_single',
            },
        },
        'RR': {
            'singleInput': {
                'port': (con, 1),
            },
            "digitalInputs": {
                "digital_input1": {
                    "port": (con, 1),
                    "delay": 0,
                    "buffer": 0,
                },
            },
            'outputs': {
                    'out1': (con, 1),
                },
            'time_of_flight': 180,
            'smearing': 0,
            'intermediate_frequency': qubit_IF,
            'operations': {
                'readout': 'readout_pulse_single',
                'sqrt': 'sqrt_pulse'
            },
        },
    },
    'pulses': {
        'cw': {
            'operation': 'control',
            'length': gauss_len,
            'waveforms': {
                'I': 'const_wf',
                'Q': 'zero_wf',
            },
        },
        'cw_single': {
            'operation': 'control',
            'length': gauss_len,
            'waveforms': {
                'single': 'const_wf'
            },
        },
        'gaussian_pulse': {
            'operation': 'control',
            'length': gauss_len,
            'waveforms': {
                'I': 'gauss_wf',
                'Q': 'zero_wf',
            },
        },
        'pi_pulse': {
            'operation': 'control',
            'length': pi_len,
            'waveforms': {
                'I': 'pi_wf',
                'Q': 'zero_wf',
            },
        },
        'pi_half_pulse': {
            'operation': 'control',
            'length': pi_half_len,
            'waveforms': {
                'I': 'pi_half_wf',
                'Q': 'zero_wf',
            },
        },
        'gaussian_pulse_single': {
            'operation': 'control',
            'length': gauss_len,
            'waveforms': {
                'single': 'gauss_wf'
            },
        },
        'pi_pulse_single': {
            'operation': 'control',
            'length': pi_len,
            'waveforms': {
                'single': 'pi_wf'
            },
        },
        'pi_half_pulse_single': {
            'operation': 'control',
            'length': pi_half_len,
            'waveforms': {
                'single': 'pi_half_wf'
            },
        },
        'readout_pulse': {
            'operation': 'measurement',
            'length': readout_len,
            'waveforms': {
                'I': 'readout_wf',
                'Q': 'zero_wf',
            },
            'integration_weights': {
                'cos': 'cosine_weights',
                'sin': 'sine_weights',
                'minus_sin': 'minus_sine_weights',
            },
            'digital_marker': 'ON',
        },
        'readout_pulse_single': {
            'operation': 'measurement',
            'length': readout_len,
            'waveforms': {
                'single': 'readout_wf',
            },
            'integration_weights': {
                'cos': 'cosine_weights',
                'sin': 'sine_weights',
            },
            'digital_marker': 'ON',
        },
    },

    'waveforms': {
        'const_wf': {'type': 'constant', 'sample': const_amp},
        'zero_wf': {'type': 'constant', 'sample': 0.0},
        'gauss_wf': {'type': 'arbitrary', 'samples': gauss_wf.tolist()},
        'pi_wf': {'type': 'arbitrary', 'samples': pi_wf.tolist()},
        'pi_half_wf': {'type': 'arbitrary', 'samples': pi_half_wf.tolist()},
        'readout_wf': {'type': 'constant', 'sample': readout_amp},
    },

    'digital_waveforms': {
        'ON': {'samples': [(1, 0)]},
        'TRIG': {'samples': [(1, 1000)]},
    },

    'integration_weights': {
        'short_cosine_weights': {
            'cosine': [(1.0, short_readout_len)],
            'sine': [(0.0, short_readout_len)],
        },
        'short_sine_weights': {
            'cosine': [(0.0, short_readout_len)],
            'sine': [(1.0, short_readout_len)],
        },
        'short_minus_sine_weights': {
            'cosine': [(0.0, short_readout_len)],
            'sine': [(-1.0, short_readout_len)],
        },
        'cosine_weights': {
            'cosine': [(1.0, readout_len)],
            'sine': [(0.0, readout_len)],
        },
        'sine_weights': {
            'cosine': [(0.0, readout_len)],
            'sine': [(1.0, readout_len)],
        },
        'minus_sine_weights': {
            'cosine': [(0.0, readout_len)],
            'sine': [(-1.0, readout_len)],
        },
        'long_cosine_weights': {
            'cosine': [(1.0, long_readout_len)],
            'sine': [(0.0, long_readout_len)],
        },
        'long_sine_weights': {
            'cosine': [(0.0, long_readout_len)],
            'sine': [(1.0, long_readout_len)],
        },
        'long_minus_sine_weights': {
            'cosine': [(0.0, long_readout_len)],
            'sine': [(-1.0, long_readout_len)],
        },
    }
}