import numpy as np

from qua_emulator.emulator import EmulationState
from qua_emulator.action_models import PlayAction, WaitAction, GapAction, MeasureAction
from qua_emulator.config_model import QOPConfig
from qua_emulator.qua_models import QuaFixed
from fxpmath import Fxp


def round_all(v):
    if isinstance(v, list):
        return list(map(round_all, v))
    elif isinstance(v, QuaFixed):
        rounded = float(Fxp(v, n_frac=4))
        if v != rounded:
            return f"{rounded}..."
        else:
            return v
    else:
        return v


def generate_data(state, raw_config):
    config = QOPConfig(raw_config)
    qes = {qe_name: actions for qe_name, actions in state.quantum_elements.items()
           if any([isinstance(action, (PlayAction, MeasureAction)) for action in actions])}

    data = {}
    for i, (qe_name, actions) in enumerate(qes.items()):
        start_t = 0
        data_i = []
        data_q = []
        is_iq = False
        for action in actions:
            duration = action.get_length()
            d_i, d_q = get_data(action, config, duration, qe_name, start_t)
            data_i.extend(d_i)
            data_q.extend(d_q)
            start_t += duration
            wf_i, wf_q = config.get_operation_waveforms(action.pulse_name, qe_name)
            if wf_q is not None:
                is_iq = True
        if is_iq:
            data[qe_name] = [
                {"label": "I", "values": data_i},
                {"label": "Q", "values": data_q}
            ]
        else:
            data[qe_name] = [
                {"label": "single", "values": data_i}
            ]
    result = {
        'data': data,
        'time': np.arange(len(list(data.values())[0][0]["values"])).tolist()
    }
    return result


def get_iq_data(qe_name, action, config, duration, start_t):
    wf_i, wf_q = config.get_operation_waveforms(action.pulse_name, qe_name)
    t = np.array(np.arange(start_t, start_t + duration))
    if wf_i['type'] == 'constant':
        arr_i = wf_i['sample']
    elif wf_i['type'] == 'arbitrary':
        arr_i = np.array(wf_i['samples'][:int(duration)])
    else:
        raise NotImplementedError(f"waveform type \"{wf_i['type']}\" not supported")

    if wf_q is None:
        arr_q = 0
    elif wf_q['type'] == 'constant':
        arr_q = wf_q['sample']
    elif wf_q['type'] == 'arbitrary':
        arr_q = np.array(wf_q['samples'][:int(duration)])
    else:
        raise NotImplementedError(f"waveform type \"{wf_q['type']}\" not supported")

    out_i = float(action.amp) * (arr_i * np.cos(2 * np.pi * (action.frequency * t + action.phase)) -
                          arr_q * np.sin(2 * np.pi * (action.frequency * t + action.phase)))

    if wf_q is None:
        out_q = np.zeros(duration)
    else:
        out_q = float(action.amp) * (arr_i * np.sin(2 * np.pi * (action.frequency * t + action.phase)) +
                              arr_q * np.cos(2 * np.pi * (action.frequency * t + action.phase)))

    return out_i, out_q


def get_data(action, config, duration, qe_name, start_t):
    t = np.array(np.arange(start_t, start_t + duration))
    if isinstance(action, WaitAction) or isinstance(action, GapAction):
        out_i = np.zeros(duration)
        out_q = np.zeros(duration)
    elif isinstance(action, PlayAction):
        out_i, out_q = get_iq_data(qe_name, action, config, duration, start_t)
    elif isinstance(action, MeasureAction):
        play_data = action.play_data
        out_i, out_q = get_iq_data(qe_name, play_data, config, duration, start_t)
    else:
        raise NotImplementedError(action)
    return out_i, out_q
