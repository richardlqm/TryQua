import json
from contextlib import contextmanager

from qm.qua import *
from qua_emulator import QuaVersion, emulate, EmulationState, plot_results
from qua_emulator.try_qua.configuration import config
from .data import generate_data


def run(program):
    qua_version = QuaVersion.V1_0
    final_state: EmulationState = emulate(program, config, qua_version=qua_version)
    data = generate_data(final_state, config)
    data['vars'] = final_state.output
    json_str = json.dumps(data)
    return json_str

    # plt.figure()
    # for qe, d in data.items():
    #     plt.plot(d[0], label=f'{qe}_I')
    #     plt.plot(d[1], label=f'{qe}_Q')
    # plt.legend()
    # plt.show()

    # plot_results(final_state, config)
    # if show:
    #     # plt.show()
    #     fname = Path(__file__).parent / 'plot.html'
    #     # mpld3.show()
    #     mpld3.save_html(plt.gcf(), str(fname))
    # else:
    #     fname = Path(__file__).parent / 'plot.png'
    #     plt.savefig(fname)
    #     return str(fname)


@contextmanager
def qua(show=False):
    with program() as prog:
        yield
    run(prog, show=show)
