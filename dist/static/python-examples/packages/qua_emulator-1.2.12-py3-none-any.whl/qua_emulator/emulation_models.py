from dataclasses import dataclass, field
from typing import Set, Dict, List, Union

from qua_emulator.action_models import Action
from qua_emulator.qua_models import VariableName, QuantumElementName, QuaType, StreamName, QuaVersion, \
    FunctionDefinition
from qua_emulator._version import __version__

MemoryState = Dict[VariableName, QuaType]
MemoryTypes = Dict[VariableName, type]
QuantumElementsState = Dict[QuantumElementName, List[Action]]
Output = Dict[StreamName, List[QuaType]]
Input = Dict[StreamName, List[QuaType]]
Availabilities = Dict[VariableName, Union[int, List[int]]]
PhasesState = Dict[QuantumElementName, int]
FrequenciesState = Dict[QuantumElementName, int]
TimeState = Dict[QuantumElementName, int]


@dataclass
class EmulationState:
    qua_version: QuaVersion
    memory: MemoryState = field(default_factory=dict)
    types: MemoryTypes = field(default_factory=dict)
    quantum_elements: QuantumElementsState = field(default_factory=dict)
    output: Output = field(default_factory=dict)
    input: Input = field(default_factory=dict)
    availabilities: Availabilities = field(default_factory=dict)
    global_wait: int = 0
    global_availability: int = 0
    phases: PhasesState = field(default_factory=dict)
    frequencies: FrequenciesState = field(default_factory=dict)
    timestamps: TimeState = field(default_factory=dict)
    qrun_counter: int = 0
    parallel_qes: Set[str] = field(default_factory=set)
    is_in_parallel: bool = False
    functions: Dict[str, FunctionDefinition] = field(default_factory=dict)
    emulator_version: str = __version__
