from typing import Dict
from collections.abc import Iterable

import numpy as np
from fxpmath import Fxp
# from matplotlib import pyplot as plt

from qua_emulator.emulator import EmulationState
from qua_emulator.action_models import PlayAction, WaitAction, GapAction, MeasureAction
from qua_emulator.config_model import QOPConfig
from qua_emulator.qua_models import QuaFixed


def round_all(v):
    if isinstance(v, list):
        return list(map(round_all, v))
    elif isinstance(v, QuaFixed):
        rounded = float(Fxp(v, n_frac=4))
        if v != rounded:
            return f"{rounded}..."
        else:
            return v
    else:
        return v


def plot_results(state: EmulationState, raw_config: Dict, figure=None):
    if figure is None:
        figure = plt.figure()
    config = QOPConfig(raw_config)
    qes = {qe_name: actions for qe_name, actions in state.quantum_elements.items()
           if any([isinstance(action, (PlayAction, MeasureAction)) for action in actions])}

    text = ', '.join([f"{v_name}={round_all(v_value)}" for v_name, v_value in state.memory.items()])
    figure.text(0.5, 0.9, text, horizontalalignment='center', verticalalignment='center')
    program_length = max([0]+[sum(action.get_length() for action in actions) for qe, actions in qes.items()])
    header = f"Quantum Elements Outputs (QUAv{state.qua_version.value})"
    if len(qes) == 0:
        figure.suptitle(f'{header}- nothing to plot ☺')
        figure.show()
        return

    figure.suptitle(f'{header} [{program_length} ns]')
    gs = figure.add_gridspec(len(qes), hspace=0.0)
    axs = gs.subplots(sharex=True, sharey=True)
    if not isinstance(axs, Iterable):
        axs = [axs]
    for i, (qe_name, actions) in enumerate(qes.items()):
        axs[i].set_ylabel(qe_name)
        axs[i].set_ylim([-0.6, +0.6])
        axs[i].axhline(0.5, color='r', linewidth=0.4, linestyle="dashed")
        axs[i].axhline(0.0, color='gray', linewidth=0.4, linestyle="dashed")
        axs[i].axhline(-0.5, color='r', linewidth=0.4, linestyle="dashed")
        axs[i].axvline(program_length, color='yellow', linewidth=0.4, linestyle="dashed")
        start_t = 0
        for action in actions:
            if len(actions) < 20:
                axs[i].axvline(start_t, color='yellow', linewidth=0.4, linestyle="dashed")
            duration = action.get_length()
            plot_action(action, axs[i], config, duration, qe_name, start_t)
            start_t += duration
    figure.show()


def get_iq_data(qe_name, action, config, duration, start_t):
    wf_i, wf_q = config.get_operation_waveforms(action.pulse_name, qe_name)
    t = np.array(np.arange(start_t, start_t + duration))
    if wf_i['type'] == 'constant':
        arr_i = wf_i['sample']
    elif wf_i['type'] == 'arbitrary':
        arr_i = np.array(wf_i['samples'][:int(duration)])
    else:
        raise NotImplementedError(f"waveform type \"{wf_i['type']}\" not supported")

    if wf_q is None:
        arr_q = 0
    elif wf_q['type'] == 'constant':
        arr_q = wf_q['sample']
    elif wf_q['type'] == 'arbitrary':
        arr_q = np.array(wf_q['samples'][:int(duration)])

    out_i = action.amp * (arr_i * np.cos(2 * np.pi * (action.frequency * t + action.phase)) -
                          arr_q * np.sin(2 * np.pi * (action.frequency * t + action.phase)))

    out_q = None
    if wf_q is not None:
        out_q = action.amp * (arr_i * np.sin(2 * np.pi * (action.frequency * t + action.phase)) +
                              arr_q * np.cos(2 * np.pi * (action.frequency * t + action.phase)))

    return t, out_i, out_q


def plot_action(action, ax, config, duration, qe_name, start_t):
    if isinstance(action, WaitAction):
        ax.plot([start_t, start_t + duration], [0, 0], color="green")
    elif isinstance(action, GapAction):
        if action.is_in_qrun:
            ax.axvspan(start_t, start_t + duration, color='red', alpha=0.3)
            ax.plot([start_t, start_t + duration], [0, 0], color="black")
        else:
            ax.plot([start_t, start_t + duration], [0, 0], color="black")
    elif isinstance(action, PlayAction):
        t, out_i, out_q = get_iq_data(qe_name, action, config, duration, start_t)
        ax.plot(t, out_i, color="red")

        if out_q is not None:
            ax.plot(t, out_q, color="blue")

    elif isinstance(action, MeasureAction):
        play_data = action.play_data
        t, out_i, out_q = get_iq_data(qe_name, play_data, config, duration, start_t)
        ax.plot(t, out_i, color="red")

        if out_q is not None:
            ax.plot(t, out_q, color="blue")
    else:
        raise NotImplementedError(action)
