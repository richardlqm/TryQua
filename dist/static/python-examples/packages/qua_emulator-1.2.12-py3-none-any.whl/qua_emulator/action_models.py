from abc import ABC, abstractmethod


class Action(ABC):
    @abstractmethod
    def get_length(self) -> int:
        pass


class PlayAction(Action):
    def __init__(self, pulse_name: str, length: int, amp: float, phase: int, frequency: int):
        self.pulse_name = pulse_name
        self.length = length
        self.amp = amp
        self.phase = phase
        self.frequency = frequency

    def get_length(self) -> int:
        return self.length

    def __repr__(self):
        return f"play pulse {self.pulse_name} for {self.length}"


class WaitAction(Action):
    def __init__(self, length):
        self.length = length

    def get_length(self) -> int:
        return self.length

    def __repr__(self):
        return f"wait for {self.length}"


class GapAction(Action):
    def __init__(self, length: int, is_in_qrun: bool):
        self.length = length
        self.is_in_qrun = is_in_qrun

    def get_length(self) -> int:
        return self.length


class MeasureAction(Action):
    def __init__(self, pulse_name: str, length: int, amp: float, phase: int, frequency: int):
        self.play_data = PlayAction(pulse_name, length, amp, phase, frequency)

    def get_length(self) -> int:
        return self.play_data.length

    def __repr__(self):
        return f"Measure pulse {self.play_data.pulse_name} for {self.play_data.length}"