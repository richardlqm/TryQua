import dataclasses
import operator
import pickle
import random
from typing import Dict, Tuple

from qm.pb.inc_qua_pb2 import QuaProgram as _Q
from qm.program import _Program
from qm.qua._dsl import _Expression

from qua_emulator.action_models import PlayAction, WaitAction, GapAction, MeasureAction
from qua_emulator.config_model import QOPConfig
from qua_emulator.emulation_models import EmulationState, Input, MemoryState, Availabilities, QuantumElementsState, \
    MemoryTypes
from qua_emulator.qua_models import QuaVersion, QuaPrimitive, QuantumElementName, FunctionDefinition, \
    cast_to_qua_by_type, QuaFixed, QuaInteger, QuaBoolean

SUPPORTED_QUA_VERSIONS = [QuaVersion.V1_0, QuaVersion.V1_5, QuaVersion.V2_0, ]


def emulate(qua_program: _Program, raw_config: Dict, qua_version: QuaVersion, seed=123, input: Input = None) \
        -> EmulationState:
    assert qua_version in SUPPORTED_QUA_VERSIONS, \
        f"Unsupported QUA version {qua_version}, currently supports only: {SUPPORTED_QUA_VERSIONS}"
    random.seed(seed)
    initial_variables_values, types, initial_availabilities = \
        _handle_declarations(qua_program._program.script.variables)
    statements = qua_program._program.script.body.statements
    qop_config = QOPConfig(raw_config)
    initial_quantum_elements_state: QuantumElementsState = {qe: [] for qe in qop_config.get_qe_names()}
    initial_timestamps = {qe: 0 for qe in qop_config.get_qe_names()}
    initial_state = EmulationState(
        qua_version=qua_version,
        memory=initial_variables_values,
        types=types,
        availabilities=initial_availabilities,
        quantum_elements=initial_quantum_elements_state,
        timestamps=initial_timestamps,
        input=input.copy() if input is not None else {},
    )
    for qe in qop_config.get_qe_names():
        qe_cfg = qop_config.get_qe_configuration(qe)
        if 'intermediate_frequency' in qe_cfg:
            initial_state.frequencies[qe] = qe_cfg['intermediate_frequency'] / 1e9
    final_state = _emulate_statements(qop_config, initial_state, statements)
    final_state.quantum_elements = _pad_qes_samples(final_state, final_state.quantum_elements)
    temp_tag_names = list(final_state.output)
    for temp_tag_name in temp_tag_names:
        values = final_state.output.pop(temp_tag_name)
        tag_index = 2*(int(temp_tag_name[1:])-1)
        tag = qua_program.result_analysis._saves[tag_index].tag
        final_state.output[tag] = values

    return final_state


def _evaluate_qua_expression(qua_expression, memory: MemoryState, availabilities: Availabilities) \
        -> Tuple[QuaPrimitive, int]:
    if isinstance(qua_expression, int):
        return QuaInteger(qua_expression), 0
    elif isinstance(qua_expression, float):
        return QuaFixed(qua_expression), 0
    elif isinstance(qua_expression, bool):
        return QuaBoolean(qua_expression), 0
    elif isinstance(qua_expression, _Expression):
        return _evaluate_qua_expression(qua_expression._exp, memory, availabilities)
    elif isinstance(qua_expression, _Q.ArrayVarRefExpression):
        return memory[qua_expression.name], max(availabilities[qua_expression.name])
    elif hasattr(qua_expression, 'scalar'):
        return _evaluate_qua_expression(qua_expression.scalar, memory, availabilities)
    elif hasattr(qua_expression, 'array'):
        return _evaluate_qua_expression(qua_expression.array, memory, availabilities)
    elif qua_expression.variable.name != '':
        var_name = qua_expression.variable.name
        return memory[var_name], availabilities.get(var_name, 0)
    elif qua_expression.arrayCell.arrayVar.name != '':
        index_value, index_availability = \
            _evaluate_qua_expression(qua_expression.arrayCell.index, memory, availabilities)
        if index_value < 0:
            raise ValueError(f"Index cannot be negative, but got: \"{index_value}\"")
        array_name = qua_expression.arrayCell.arrayVar.name
        cell_value = memory[array_name][index_value.as_python]
        cell_availability = availabilities.get(array_name, 0)
        if len(cell_availability) > 0:
            cell_availability = cell_availability[index_value.as_python]
        return cell_value, max(index_availability, cell_availability)
    elif qua_expression.literal.value != '':
        return eval(qua_expression.literal.value), 0
    elif qua_expression.libFunction.loc != '' and qua_expression.libFunction.libraryName == 'user':
        if qua_expression.libFunction.functionName == 'get':
            argument_name = qua_expression.libFunction.loc
            if argument_name not in memory:
                raise KeyError(f'No argument with name {argument_name}')
            return memory[argument_name], availabilities[argument_name]
        else:
            raise NotImplementedError(f'Function not implemented: {qua_expression.libFunction.functionName}')
    elif qua_expression.libFunction.loc != '':
        math_library = {

        }
        util_library = {

        }
        cast_library = {
            'unsafe_cast_fixed': QuaFixed.cast,
        }
        libraries = {
            'math': math_library,
            'util': util_library,
            'cast': cast_library,
        }
        parsed_args, avails = list(zip(*[_evaluate_qua_expression(arg, memory, availabilities)
                                         for arg in qua_expression.libFunction.arguments]))
        try:
            library = libraries[qua_expression.libFunction.libraryName]
        except KeyError:
            raise ValueError(f"Unknown library: \"{qua_expression.libFunction.libraryName}\"")
        try:
            func = library[qua_expression.libFunction.functionName]
        except KeyError:
            raise ValueError(f"Unknown function \"{qua_expression.libFunction.functionName}\" "
                             f"at library \"{qua_expression.libFunction.libraryName}\"")
        return func(*parsed_args), max(avails)
    elif qua_expression.binaryOperation.loc != '':
        lhs_value, lhs_avail = _evaluate_qua_expression(qua_expression.binaryOperation.left, memory, availabilities)
        rhs_value, rhs_avail = _evaluate_qua_expression(qua_expression.binaryOperation.right, memory, availabilities)
        operation = {
            0: operator.add,
            1: operator.sub,
            2: operator.mul,
            3: operator.floordiv if _is_int(lhs_value) and _is_int(rhs_value) else operator.truediv,
            4: operator.and_,
            5: operator.or_,
            6: operator.xor,
            7: operator.lt,
            8: operator.le,
            9: operator.gt,
            10: operator.ge,
            11: operator.eq,
            12: operator.lshift,
            13: operator.rshift,
        }[qua_expression.binaryOperation.op]
        return operation(lhs_value, rhs_value), max(lhs_avail, rhs_avail)
    else:
        raise NotImplementedError("Unsupported QUA expression at: " + str(qua_expression))


def _is_int(value):
    return isinstance(value, (QuaInteger, QuaBoolean, int))


def _pad_qes_samples(state: EmulationState, original_qes_samples: QuantumElementsState, qes_names=None, is_wait=False):
    if qes_names is None:
        qes_names = list(original_qes_samples)
    qes_samples = {qe_name: original_qes_samples[qe_name] if qe_name in original_qes_samples else []
                   for qe_name in qes_names}
    qes_samples = qes_samples.copy()
    max_length = max([0] + list(state.timestamps.values()))
    for qe_name in qes_samples:
        qe_duration = state.timestamps.get(qe_name, 0)
        pad_length = max_length - qe_duration
        if pad_length > 0:
            if is_wait:
                action = WaitAction(pad_length)
            else:
                action = GapAction(pad_length, is_in_qrun=state.qrun_counter > 0)
            qes_samples[qe_name].append(action)
            state.timestamps[qe_name] = state.timestamps.get(qe_name, 0) + pad_length

    return {**original_qes_samples.copy(), **qes_samples}


PROCESSING_LATENCY = 0


def _gap_until_availability(state: EmulationState, availability_time: int, *qe_names: QuantumElementName):
    _delay_until_availability(state, availability_time, True, *qe_names)


def _wait_until_availability(state: EmulationState, availability_time: int, *qe_names: QuantumElementName):
    _delay_until_availability(state, availability_time, False, *qe_names)


def _delay_until_availability(state: EmulationState, availability_time: int, is_gap: bool,
                              *qe_names: QuantumElementName):
    qes_samples = state.quantum_elements
    qe_names = list(qes_samples) if len(qe_names) == 0 else qe_names
    for qe_name in qe_names:
        time_so_far = state.timestamps.get(qe_name, 0)
        time_difference = max(availability_time, state.global_availability) - time_so_far
        if time_difference > 0:
            if qe_name not in qes_samples:
                qes_samples[qe_name] = []
            if is_gap:
                action = GapAction(time_difference, is_in_qrun=state.qrun_counter > 0)
            else:
                action = WaitAction(time_difference)
            qes_samples[qe_name].append(action)
            state.timestamps[qe_name] = state.timestamps.get(qe_name, 0) + time_difference


def _update_global_availability(state: EmulationState, avail: int) -> None:
    if avail > state.global_availability:
        state.global_availability = avail


def _emulate_statements(config: QOPConfig, initial_state: EmulationState, statements: list) -> EmulationState:
    current_state = dataclasses.replace(initial_state)

    for statement in statements:
        if current_state.qua_version is QuaVersion.V2_0 and not current_state.is_in_parallel:
            current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)

        statement_type = statement.WhichOneof('statement_oneof')

        if statement_type == 'rus':
            loc = statement.rus.loc
            statement_type, data = loc.split(' ', maxsplit=1)
            statement = type(f"{statement_type}Instruction", (object, ), pickle.loads(bytearray.fromhex(data)))()
        elif statement_type == 'qrun' and statement.qrun.loc[0] == '@':
            loc = statement.qrun.loc[1:]
            statement_type, data = loc.split(' ', maxsplit=1)
            statement = type(f"{statement_type}Context", (object, ), {'statements': statement.qrun.body.statements} |
                             pickle.loads(bytearray.fromhex(data)))()

        if statement_type == 'wait':
            duration, avail = _evaluate_qua_expression(
                statement.wait.time, current_state.memory, current_state.availabilities)
            if duration < 0:
                raise ValueError(f"Wait duration cannot be negative, but got: \"{duration}\"")
            if len(statement.wait.qe) > 0:
                qes_names = [qe.name for qe in statement.wait.qe]
            else:
                qes_names = list(current_state.quantum_elements)
            for qe_name in qes_names:
                if qe_name not in current_state.quantum_elements:
                    current_state.quantum_elements[qe_name] = []
                _gap_until_availability(current_state, avail, qe_name)
                current_state.quantum_elements[qe_name].append(WaitAction(duration))
                current_state.timestamps[qe_name] = current_state.timestamps.get(qe_name, 0) + duration
        elif statement_type == 'assert_':
            condition, avail = _evaluate_qua_expression(
                statement.condition, current_state.memory, current_state.availabilities)
            if not condition:
                raise AssertionError(statement.message)
        elif statement_type == 'wait_for_value':
            _, avail = _evaluate_qua_expression(statement.value, current_state.memory, current_state.availabilities)
            min_time = getattr(statement, 'min_time', 0)
            if min_time < 0:
                raise ValueError(f"Minimum wait for value time must be non-negative ({min_time})")
            max_time = getattr(statement, 'max_time', float('inf'))
            if max_time < min_time:
                raise ValueError(f"Maximum wait for value time must be greater or equal to minimum "
                                 f"(min={min_time}, max={max_time})")
            qe_names = getattr(statement, 'qes', [])
            for qe_name in qe_names:
                delay = avail - current_state.timestamps[qe_name]
                if not min_time <= delay <= max_time:
                    raise RuntimeError(f"Quantum element \"{qe_name}\" will wait for ({delay}) until value, "
                                       f"but allowed range is [{min_time},{max_time}]")
            _wait_until_availability(current_state, avail, *qe_names)
        elif statement_type == 'say':
            final_msg = ""
            for msg in statement.msgs:
                if type(msg) == str:
                    final_msg += msg
                else:
                    value, _ = _evaluate_qua_expression(msg, current_state.memory, current_state.availabilities)
                    final_msg += str(value)
            print(final_msg)
        elif statement_type == 'parallel_':
            if all([sub_statement.WhichOneof('statement_oneof') != 'thread_'
                    for sub_statement in statement.statements]):
                current_state.is_in_parallel = True
                old_functions = current_state.functions.copy()
                current_state = _emulate_statements(config, current_state, statement.statements)
                current_state.functions = old_functions
                current_state.is_in_parallel = False
            else:
                raise NotImplementedError("Parallel execution with threads is not implemented yet")
        elif statement_type == 'beep':
            pass  # beepy.beep(sound="beep")
        elif statement_type == 'play':
            qe_name = statement.play.qe.name
            _gap_until_global_availability(current_state, qe_name)
            pulse_name = statement.play.pulse.name
            pulse_duration = config.get_pulse_duration(qe_name, pulse_name)
            try:
                truncate, truncate_avail = _evaluate_qua_expression(
                    statement.play.truncate, current_state.memory, current_state.availabilities)
                if truncate < 0:
                    raise ValueError(f"Play truncate cannot be negative, but got: \"{truncate}\"")
                _gap_until_availability(current_state, truncate_avail, qe_name)
            except NotImplementedError:
                truncate = None
            try:
                duration, duration_avail = _evaluate_qua_expression(
                    statement.play.duration, current_state.memory, current_state.availabilities)
                if duration < 0:
                    raise ValueError(f"Play duration cannot be negative, but got: \"{duration}\"")
                _gap_until_availability(current_state, duration_avail, qe_name)
            except NotImplementedError:
                duration = None
            if duration is not None and truncate is not None:
                raise NotImplementedError("Duration and Truncate are not supported simultaneously")
            elif duration is not None:
                final_duration = duration
            elif truncate is not None:
                if truncate > pulse_duration:
                    raise ValueError(f"Cannot truncate (={truncate}) more than pulse length (={pulse_duration})")
                final_duration = truncate
            else:
                final_duration = pulse_duration
            if statement.play.HasField('amp'):
                amp, amp_avail = _evaluate_qua_expression(
                    statement.play.amp.v0, current_state.memory, current_state.availabilities)
                if amp < 0:
                    raise ValueError(f"Play amplitude cannot be negative, but got: \"{amp}\"")
                _gap_until_availability(current_state, amp_avail, qe_name)
            else:
                amp = 1
            measure_action = PlayAction(pulse_name, final_duration, amp, current_state.phases.get(qe_name, 0),
                                        current_state.frequencies.get(qe_name, 0))
            if qe_name not in current_state.quantum_elements:
                current_state.quantum_elements[qe_name] = []
            current_state.quantum_elements[qe_name].append(measure_action)
            current_state.timestamps[qe_name] = current_state.timestamps.get(qe_name, 0) + final_duration
        elif statement_type == 'align':
            if len(statement.align.qe) > 0:
                qes_names = [qe.name for qe in statement.align.qe]
            else:
                qes_names = list(current_state.quantum_elements)
            current_state.quantum_elements = _pad_qes_samples(
                current_state, current_state.quantum_elements, qes_names, is_wait=True)
        elif statement_type == 'assign':
            if statement.assign.target.variable.name != '':
                value, value_avail = _evaluate_qua_expression(
                    statement.assign.expression, current_state.memory, current_state.availabilities)
                variable_name = statement.assign.target.variable.name
                casted_value = cast_to_qua_by_type(value, current_state.types[variable_name])
                current_state.memory[variable_name] = casted_value
                current_state.availabilities[statement.assign.target.variable.name] = value_avail
            elif statement.assign.target.arrayCell.arrayVar.name != '':
                index, index_avail = _evaluate_qua_expression(
                    statement.assign.target.arrayCell.index, current_state.memory, current_state.availabilities)
                if index < 0:
                    raise ValueError(f"Index cannot be negative, but got: \"{index}\"")
                value, value_avail = _evaluate_qua_expression(
                    statement.assign.expression, current_state.memory, current_state.availabilities)
                array_name = statement.assign.target.arrayCell.arrayVar.name
                casted_value = cast_to_qua_by_type(value, current_state.types[array_name])
                current_state.memory[array_name][int(index)] = casted_value
                # todo - this int(index) is bad, it comes to cover faults in evaluation of the qua expression
                if statement.assign.target.arrayCell.arrayVar.name not in current_state.availabilities:
                    zeros = [0] * len(current_state.memory[statement.assign.target.arrayCell.arrayVar.name])
                    current_state.availabilities[statement.assign.target.arrayCell.arrayVar.name] = zeros
                current_state.availabilities[statement.assign.target.arrayCell.arrayVar.name][int(index)] = \
                    max(index_avail, value_avail)
            else:
                raise NotImplementedError(f"Unsupported assign target at: {statement.assign.target}")
        elif statement_type == 'if':
            if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
            if_statement = getattr(statement, "if")
            if_condition_value, if_condition_value_avail = _evaluate_qua_expression(
                if_statement.condition, current_state.memory, current_state.availabilities)
            old_avail = current_state.global_availability
            _update_global_availability(current_state, if_condition_value_avail)
            elif_statements = if_statement.elseifs
            else_statement = getattr(if_statement, "else")

            next_statements = None
            if if_condition_value:
                next_statements = if_statement.body.statements
            else:
                for elif_statement in elif_statements:
                    elif_condition_value, elif_condition_value_avail = _evaluate_qua_expression(
                        elif_statement.condition, current_state.memory, current_state.availabilities)
                    _update_global_availability(current_state, elif_condition_value)
                    if elif_condition_value:
                        next_statements = elif_statement.body.statements
                next_statements = else_statement.statements if next_statements is None else next_statements
            if next_statements is not None:
                old_functions = current_state.functions.copy()
                current_state = _emulate_statements(config, current_state, next_statements)
                current_state.functions = old_functions
            current_state.global_availability = old_avail
            if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
        elif statement_type == 'for':
            if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
            loop = getattr(statement, "for")
            old_avail = current_state.global_availability
            current_state = _emulate_statements(config, current_state, loop.init.statements)
            while True:
                if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                    current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
                cond_value, cond_value_avail = _evaluate_qua_expression(
                    loop.condition, current_state.memory, current_state.availabilities)
                _update_global_availability(current_state, cond_value_avail)
                if not cond_value:
                    break
                old_functions = current_state.functions.copy()
                current_state = _emulate_statements(config, current_state, loop.body.statements)
                current_state.functions = old_functions
                current_state = _emulate_statements(config, current_state, loop.update.statements)
            current_state.global_availability = old_avail
            if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
        elif statement_type == 'save':
            tag = statement.save.tag
            if tag not in current_state.output:
                current_state.output[tag] = []
            value, value_avail = _evaluate_qua_expression(
                statement.save.source, current_state.memory, current_state.availabilities)  # TODO
            current_state.output[tag].append(value.as_python)
        elif statement_type == 'zRotation':
            qe_name = statement.zRotation.qe.name
            _gap_until_global_availability(current_state, qe_name)
            value, value_avail = _evaluate_qua_expression(
                statement.zRotation.value, current_state.memory, current_state.availabilities)
            _gap_until_availability(current_state, value_avail, qe_name)
            current_state.phases[qe_name] = value
        elif statement_type == 'resetFrame':
            qe_name = statement.resetFrame.qe.name
            _gap_until_global_availability(current_state, qe_name)
            current_state.phases[qe_name] = 0
        elif statement_type == 'resetPhase':
            qe_name = statement.resetPhase.qe.name
            _gap_until_global_availability(current_state, qe_name)
            current_state.phases[qe_name] = 0
        elif statement_type == 'updateFrequency':
            qe_name = statement.updateFrequency.qe.name
            _gap_until_global_availability(current_state, qe_name)
            value, value_avail = _evaluate_qua_expression(
                statement.updateFrequency.value, current_state.memory, current_state.availabilities)
            _gap_until_availability(current_state, value_avail, qe_name)
            new_frequency = value / {
                # 0: 1_000_000_000_000,
                0: 1_000_000_000,  # TODO seems that MHz (default) is index 0
                2: 1_000_000,
                3: 1_000,
                4: 1,
            }[statement.updateFrequency.units]
            current_state.frequencies[qe_name] = new_frequency
            should_keep_phase, cond_avail = _evaluate_qua_expression(
                statement.updateFrequency.keepPhase, current_state.memory, current_state.availabilities)
            _gap_until_availability(current_state, cond_avail, qe_name)
            if not should_keep_phase:
                current_state.phases[qe_name] = 0
        elif statement_type == 'qrun':
            body_statements = statement.qrun.body.statements
            old_functions = current_state.functions.copy()
            current_state.qrun_counter += 1
            current_state = _emulate_statements(config, current_state, body_statements)
            current_state.functions = old_functions
            current_state.qrun_counter -= 1
        elif statement_type == 'advanceInputStream':
            if statement.advanceInputStream.streamVariable.name != '':
                name = statement.advanceInputStream.streamVariable.name
            else:
                name = statement.advanceInputStream.streamArray.name
            if name not in current_state.input:
                raise Exception("Input stream {} not found".format(name))
            elif len(current_state.input[name]) == 0:
                raise Exception("Input stream {} is empty".format(name))
            else:
                value = current_state.input[name].pop(0)
                casted_value = cast_to_qua_by_type(value, current_state.types[name])
                current_state.memory[name] = casted_value
        elif statement_type == 'def_function':
            if statement.name in current_state.functions:
                raise Exception("Function \"{}\" already defined".format(statement.name))
            current_state.functions[statement.name] = \
                FunctionDefinition(statement.name, statement.arguments, list(statement.statements))
        elif statement_type == 'call_function':
            if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
            old_avail = current_state.global_availability

            if statement.name not in current_state.functions:
                raise Exception("Function \"{}\" not defined".format(statement.name))
            function: FunctionDefinition = current_state.functions[statement.name]
            old_functions = current_state.functions.copy()
            old_arguments = {}
            for arg_name, arg_value in function.arguments.items():
                if arg_name in current_state.memory:
                    old_arguments[arg_name] = (current_state.memory[arg_name], current_state.availabilities[arg_name])
                if arg_name in statement.args:
                    value, avail = _evaluate_qua_expression(statement.args[arg_name], current_state.memory,
                                                            current_state.availabilities)
                else:
                    value, avail = arg_value, 0
                value = current_state.input[arg_name].pop(0)
                casted_value = cast_to_qua_by_type(value, current_state.types[arg_name])
                current_state.memory[arg_name] = casted_value
                current_state.availabilities[arg_name] = avail
            current_state = _emulate_statements(config, current_state, function.body)
            for arg_name, arg_value in function.arguments.items():
                current_state.memory.pop(arg_name)
                if arg_name in old_arguments:
                    value = old_arguments[arg_name][0]
                    casted_value = cast_to_qua_by_type(value, current_state.types[arg_name])
                    current_state.memory[arg_name] = casted_value
                    current_state.availabilities[arg_name] = old_arguments[arg_name][1]
            current_state.functions = old_functions
            current_state.global_availability = old_avail
            if current_state.qua_version in (QuaVersion.V1_5, QuaVersion.V2_0):
                current_state.quantum_elements = _pad_qes_samples(current_state, current_state.quantum_elements)
        elif statement_type == 'measure':
            qe_name = statement.measure.qe.name
            _gap_until_global_availability(current_state, qe_name)
            pulse_name = statement.measure.pulse.name
            if pulse_name == '':
                _handle_acquire_statement(current_state, 0, qe_name, statement.measure.measureProcesses)
                continue
            pulse_duration = config.get_pulse_duration(qe_name, pulse_name)
            if statement.measure.amp.loc != '':
                amp, amp_avail = _evaluate_qua_expression(statement.measure.amp.v0, current_state.memory,
                                                          current_state.availabilities)
                if amp < 0:
                    raise ValueError(f"Measurement amplitude cannot be negative, but got: \"{amp}\"")
                _gap_until_availability(current_state, amp_avail, qe_name)
            else:
                amp = 1
            phase = current_state.phases.get(qe_name, 0)
            frequency = current_state.frequencies.get(qe_name, 0)
            measure_action = MeasureAction(pulse_name, pulse_duration, amp, phase, frequency)
            if qe_name not in current_state.quantum_elements:
                current_state.quantum_elements[qe_name] = []
            current_state.quantum_elements[qe_name].append(measure_action)
            current_state.timestamps[qe_name] = current_state.timestamps.get(qe_name, 0) + pulse_duration
            latency = config.get_time_of_flight(qe_name) + config.get_smearing(qe_name)
            _handle_acquire_statement(current_state, latency, qe_name, statement.measure.measureProcesses)
        else:
            raise NotImplementedError(f"Unsupported QUA instruction at: {statement}")

    return current_state


def _handle_acquire_statement(current_state: EmulationState, latency: int, qe_name: QuantumElementName, processes):
    time_so_far = current_state.timestamps.get(qe_name, 0)
    time_to_results = latency + PROCESSING_LATENCY
    results_availability = time_so_far + time_to_results
    for process in processes:
        if process.analog.loc != '':
            demod = process.analog.demodIntegration
            target = demod.target.scalarProcess
            rand_value = QuaFixed(random.uniform(-8, 8))
            if target.variable.name != '':
                current_state.memory[target.variable.name] = rand_value
                current_state.availabilities[target.variable.name] = results_availability
            elif target.arrayCell.arrayVar.name != '':
                index, index_avail = _evaluate_qua_expression(target.arrayCell.index, current_state.memory,
                                                              current_state.availabilities)
                if index < 0:
                    raise ValueError(f"Index cannot be negative, but got: \"{index}\"")
                _gap_until_availability(current_state, index_avail, qe_name)
                current_state.memory[target.arrayCell.arrayVar.name][index] = rand_value
                current_state.availabilities[target.arrayCell.arrayVar.name][index] = results_availability
        else:
            raise NotImplementedError("Only analog measurements are allowed:", process)


def _gap_until_global_availability(current_state: EmulationState, *qe_names: QuantumElementName):
    _gap_until_availability(current_state, current_state.global_availability, *qe_names)


def _wait_until_global_availability(current_state: EmulationState, *qe_names: QuantumElementName):
    _wait_until_availability(current_state, current_state.global_availability, *qe_names)


def _handle_declarations(variables: list) -> Tuple[MemoryState, MemoryTypes, Availabilities]:
    default_value = 0
    memory: MemoryState = {}
    types: MemoryTypes = {}
    availabilities: Availabilities = {}
    for declaration in variables:
        if declaration.dim == 0:
            if len(declaration.value) == 1:
                value = cast_to_qua_by_type(declaration.value[0].value, declaration.type)
            else:
                value = cast_to_qua_by_type(default_value, declaration.type)
            memory[declaration.name] = value
            types[declaration.name] = declaration.type
            availabilities[declaration.name] = 0
        elif declaration.dim == 1:
            if len(declaration.value) == 0:
                values = [cast_to_qua_by_type(default_value, declaration.type)] * declaration.size
            else:
                values = [cast_to_qua_by_type(value.value, declaration.type) for value in declaration.value]
            memory[declaration.name] = values
            types[declaration.name] = declaration.type
            availabilities[declaration.name] = [0] * len(values)
        else:
            raise NotImplementedError(f"Unsupported array dimensions \"{declaration.dim}\" at: {declaration}")
    return memory, types, availabilities
