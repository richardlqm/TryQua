
def program():
    pass


def play(operation, element):
    pass


def wait(duration, *elements):
    pass