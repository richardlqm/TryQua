import dataclasses
from enum import Enum
from typing import List, Union, Dict

from fxpmath import Fxp


class QuaVersion(Enum):
    V1_0 = 1.0
    V1_5 = 1.5
    V2_0 = 2.0


@dataclasses.dataclass
class FunctionDefinition:
    name: str
    arguments: Dict[str, object]
    body: List[object]


class QuaPrimitive(Fxp):
    word_length: int
    frac_length: int
    pythonic_type: type

    def __init__(self, value):
        super().__init__(value, signed=True, n_word=self.word_length, n_frac=self.frac_length,
                         rounding="floor", overflow="wrap", shifting="keep")
        self._log_overflow(value)

    def _log_overflow(self, orig_value) -> None:
        if self.status['overflow']:
            print(f'Overflow: {orig_value} -> {self}')
        if self.status['underflow']:
            print(f'Underflow: {orig_value} -> {self}')

    @property
    def as_python(self):
        return self.pythonic_type(self)


class QuaBoolean(QuaPrimitive):
    word_length = 1
    frac_length = 0
    pythonic_type = bool

    def __init__(self, value):
        if isinstance(value, str):
            value = value == 'True'
        super().__init__(value)


class QuaInteger(QuaPrimitive):
    word_length = 32
    frac_length = 0
    pythonic_type = int


class QuaFixed(QuaPrimitive):
    word_length = 32
    frac_length = 28
    pythonic_type = float


QuaIntegerArray = List[QuaInteger]
QuaBooleanArray = List[QuaBoolean]
QuaFixedArray = List[QuaFixed]
QuaPrimitive = Union[QuaInteger, QuaBoolean, QuaFixed]
QuaArray = Union[
    QuaIntegerArray,
    QuaBooleanArray,
    QuaFixedArray
]
QuaType = Union[QuaPrimitive, QuaArray]
VariableName = str
QuantumElementName = str
StreamName = str


def cast_to_qua_by_type(value, qua_type: int):
    qua_class = [QuaInteger, QuaBoolean, QuaFixed][qua_type]
    return qua_class(value)
